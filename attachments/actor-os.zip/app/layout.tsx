import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'actr.one — Your career, directed',
  description: 'The career operating system for working actors. Track auditions, build your craft, and keep the next move clear.',
  generator: 'actr.one',
  icons: { icon: '/brand/actr-one-primary.svg', shortcut: '/brand/actr-one-primary.svg' },
}

export const viewport: Viewport = {
  colorScheme: 'light',
  themeColor: '#f6f2eb',
  userScalable: true,
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className="bg-background">
      <body className="antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
